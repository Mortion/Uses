﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitaleKlok
{
    public partial class MainForm : Form
    {

        /// <summary>
        ///     Gemaakt door: Jarrik Van Camp
        ///     Klas: 12675
        /// </summary>

        public MainForm()
        {
            InitializeComponent();
        }
    }
}
